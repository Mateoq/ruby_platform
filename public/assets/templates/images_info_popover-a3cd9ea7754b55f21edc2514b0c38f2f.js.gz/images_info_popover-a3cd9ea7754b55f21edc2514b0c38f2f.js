prTemplates.directive('imagesInfoPopover', ['$window', '$document', '$timeout', '$sce', 'updateProgressService', function ($window, $document,$timeout, $sce, updateProgressService) {
	return {
		templateUrl: 'images_info_popover.html',
		restrict: 'E',
		scope: {
			options: '=options'
		},
		link: function (scope, element, attrs) {
			scope.options.templateClass = 'images-info-popover';

            // Variable to verify the end of the activity
            scope.count = 0;

			if (scope.options.hasOwnProperty('itemsImage')) {
				for (var i = 0; i < scope.options.itemsImage.length; i++) {
					if (angular.isString(scope.options.itemsImage[i].content)) {
						scope.options.itemsImage[i].content = $sce.trustAsHtml(scope.options.itemsImage[i].content);

						if (scope.options.done) {
							scope.options.itemsImage[i].done = true;
						}
					}
				}
			}

			// var $container = null,
			// 	$imagesBar = null;

			$timeout(function(){
				// $imagesBar = angular.element('.pr-images-info-row');
				// $container = angular.element('.images-info-popover');

				// resizeBar($container, $imagesBar);

				angular.element('.pr-image-info-item').each(function(index, el) {
					$timeout(function(){
						angular.element(el).addClass('animated fadeIn');
					}, 200 + (600 * index));
				});
			});

			// angular.element($window).on('resize', function(event) {
   //              resizeBar($container, $imagesBar);
   //          });

			// function resizeBar ($container, $imagesBar) {
			// 	var h = ($document[0].documentElement.clientHeight - 134) + 'px',
   //              	w = ($document[0].documentElement.clientWidth - 30) + 'px';

   //              $container[0].style.height = h;
   //              $container[0].style.width = w;

   //              $imagesBar.width($container.width());
   //          }

            scope.$watch('count', function (newValue, oldValue) {
                if (newValue < scope.options.itemsImage.length) return;

                // TODO: Here is going to appear the final animation
                updateProgressService(
                        gon.course_structure.class_name,
                        gon.course_structure.grade,
                        gon.course_structure.lesson_guide,
                        gon.course_structure.lesson_num
                );

                updateProgressService.update(gon.lesson_structure[scope.$root.routeIndex].url_name, scope.$root.nextItem).then(function (data) {
                	// TODO: congrats message
                	scope.$root.lessonProgress = data.lesson_progress[gon.course_app];
                	scope.$root.isNextEnabled = true;
                });
            });

            scope.show = function (event, item) {
            	if (item.done) return;

            	var $target = angular.element(event.currentTarget),
            		$popover = $target.find('.pr-image-info-popover');

            	$popover.addClass('animated bounceIn');

            	item.done = true;

                scope.count++;
            }
		}
	};
}]);
