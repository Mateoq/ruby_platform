prTemplates.directive('iconSoundImage', ['$window', '$document', '$timeout', '$sce', 'updateProgressService', function ($window, $document,$timeout, $sce, updateProgressService) {
	return {
		templateUrl: 'icon_sound_image.html',
		restrict: 'E',
		scope: {
			options: '=options'
		},
		link: function (scope, element, attrs) {
			scope.options.templateClass = 'icon_sound_image';
            scope.count = 0;
            if (scope.options.hasOwnProperty('itemsImage')) {
				for (var i = 0; i < scope.options.itemsImage.length; i++) {
					if (angular.isString(scope.options.itemsImage[i].content)) {
						scope.options.itemsImage[i].content = $sce.trustAsHtml(scope.options.itemsImage[i].content);
						if (scope.options.done) {
							scope.options.itemsImage[i].done = true;
						}
					}
				}
			}
			function iconImages (){
                var h = ($document[0].documentElement.clientHeight) + 'px',
                	w = ($document[0].documentElement.clientWidth) + 'px';
                $container.height(h);
                $container.width(w);
                $content[0].style.height = ($window.window.innerHeight) + 'px';
			} 
		}
	};
}]);




