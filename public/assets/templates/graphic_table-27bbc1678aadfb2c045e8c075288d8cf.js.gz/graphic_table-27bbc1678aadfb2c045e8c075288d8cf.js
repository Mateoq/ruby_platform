prTemplates.directive('graphicTable', ['$sce', '$window', '$document', '$timeout', 'graphicService', 'updateProgressService', function ($sce, $window, $document, $timeout, graphicService, updateProgressService) {
	return {
		templateUrl: 'graphic_table.html',
		restrict: 'E',
		scope: {
			options: '=options'
		},
		link: function (scope, element, attrs) {
			scope.options.templateClass = 'graphic-table';
			
			if (!scope.options.hasOwnProperty('method')) return;

			scope.options.canvasId = graphicService.methods[scope.options.method];

			scope.$root.game = new Phaser.Game(scope.options.graphicData.width, scope.options.graphicData.height, Phaser.CANVAS, scope.options.canvasId, null, true);

			scope.options.graphicData.atlasPath = scope.$root.resources + scope.options.graphicData.atlasMap;
			scope.options.graphicData.method = scope.options.method;
			graphicService(scope.options.graphicData, scope.$root.game, scope.options.done, function () {
				updateProgressService(
                        gon.course_structure.class_name,
                        gon.course_structure.grade,
                        gon.course_structure.lesson_guide,
                        gon.course_structure.lesson_num
                );

                updateProgressService.update(gon.lesson_structure[scope.$root.routeIndex].url_name, scope.$root.nextItem).then(function (data) {
                	// TODO: congrats message
                	scope.$root.lessonProgress = data.lesson_progress[gon.course_app];
                	scope.$root.isNextEnabled = true;
                });
			});
		}
	};
}]);
